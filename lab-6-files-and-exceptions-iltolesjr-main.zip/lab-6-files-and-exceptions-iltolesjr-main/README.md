## Java Lab 6, Files and Exceptions

Instructions:

Finish the code marked with the //TODO messages. Run and test your code to make sure it works. 
Also run the tests and make sure the autograder will think it works too.

When done, commit and push your code to your own GitHub repository. 
The autograder will check your code after the lab deadline.  

If any of the tests fail and you are sure your code is right, please tell me ASAP! 
These labs new and there may be bugs in the tests. Your help is appreciated.

Any questions? Need help? Please contact me. I'm here to help. 